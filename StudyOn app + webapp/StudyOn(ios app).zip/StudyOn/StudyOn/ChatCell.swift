//
//  ChatCell.swift
//  StudyOn
//
//  Created by justin cheng on 26/10/14.
//  Copyright (c) 2014 One Mistakes. All rights reserved.
//

import UIKit

class ChatCell: UITableViewCell {
    
    @IBOutlet var userLabel: UILabel!
    @IBOutlet var timeLabel: UILabel!
    @IBOutlet var msgTextView: UITextView!
    
    override func awakeFromNib() {
        
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        
    }
    
}