//
//  ViewController.swift
//  StudyOn
//
//  Created by justin cheng on 25/10/14.
//  Copyright (c) 2014 One Mistakes. All rights reserved.
//

import UIKit

class LogInPage: UIViewController, FBLoginViewDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        var loginView: FBLoginView = FBLoginView();
        loginView.frame = CGRectOffset(loginView.frame, (self.view.center.x - (loginView.frame.size.width / 2)), 5)
        loginView.frame.offset(dx: 0, dy: self.view.frame.size.height/2)
        loginView.delegate = self
        self.view.addSubview(loginView);
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func loginViewFetchedUserInfo(loginView: FBLoginView!, user: FBGraphUser!) {
        theUserMgr.name = user.name
        theUserMgr.id = user.objectID
        var query = PFQuery(className: "People")
        query.findObjectsInBackgroundWithTarget(self, selector: "loadedPeople:")
    }
    
    func loadedPeople(Objects: [PFObject]) {
        var objects = Objects
        var flag = 1
        for object: PFObject in objects as [PFObject] {
            if (object.objectForKey("FacebookID").isEqual(theUserMgr.id)) {
                flag = 0
            }
        }
        if (flag == 1) {
            var newUser = PFObject(className: "People")
            newUser.setObject(theUserMgr.name, forKey: "Name")
            newUser.setObject(theUserMgr.id, forKey: "FacebookID")
            newUser.save()
        }
    }

    
    func loginViewShowingLoggedInUser(loginView: FBLoginView!) {
        let storyboard = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle())
        var vc = storyboard.instantiateViewControllerWithIdentifier("GroupsPage") as UINavigationController
        self.showViewController(vc, sender: self)
    }
}

