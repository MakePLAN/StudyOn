//
//  GroupInfo.swift
//  StudyOn
//
//  Created by justin cheng on 25/10/14.
//  Copyright (c) 2014 One Mistakes. All rights reserved.
//

import UIKit

class GroupInfo: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet var infoTable: UITableView!
    var infoList = NSMutableArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        loadInfo()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func clickRefresh() {
        loadInfo()
    }
    
    func loadInfo() {
        var query = PFQuery(className: "Join")
        query.whereKey("GroupID", equalTo: theUserMgr.joinObject!.objectForKey("GroupID"))
        query.findObjectsInBackgroundWithTarget(self, selector: "loadedInfo:")
    }
    
    func loadedInfo(Objects: [PFObject]) {
        var temp = NSMutableArray()
        for object: PFObject in Objects as [PFObject] {
            temp.addObject(object)
        }
        infoList = temp
        infoTable.reloadData()
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return infoList.count
    }
    
    // Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
    // Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 60
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var cell: UITableViewCell? = tableView.dequeueReusableCellWithIdentifier("GroupInfoCell", forIndexPath: indexPath) as? UITableViewCell
        if (cell == nil) {
            cell = UITableViewCell(style: UITableViewCellStyle.Default, reuseIdentifier: "GroupInfoCell")
        }
        cell!.textLabel.text = infoList.objectAtIndex(indexPath.row).objectForKey("UserName") as? String
        return cell!
    }

}
