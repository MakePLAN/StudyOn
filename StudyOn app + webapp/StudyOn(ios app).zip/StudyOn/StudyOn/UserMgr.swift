//
//  UserMgr.swift
//  StudyOn
//
//  Created by justin cheng on 25/10/14.
//  Copyright (c) 2014 One Mistakes. All rights reserved.
//

import Foundation

var theUserMgr = UserMgr()

class UserMgr: NSObject {
    var name: String = ""
    var id: String = ""
    var groupId: String = ""
    var groupName: String = ""
    var joinObject: PFObject? = nil
}
