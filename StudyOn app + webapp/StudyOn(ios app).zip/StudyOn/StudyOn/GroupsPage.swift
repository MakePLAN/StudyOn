//
//  GroupsPage.swift
//  StudyOn
//
//  Created by justin cheng on 25/10/14.
//  Copyright (c) 2014 One Mistakes. All rights reserved.
//

import UIKit

class GroupsPage: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet var groupsTable: UITableView!
    var groupsData = NSMutableArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        loadGroups()
    }
    
    override func viewWillAppear(animated: Bool) {
        cleanJoins()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func refresh() {
        loadGroups()
    }
    
    func loadGroups() {
        var query = PFQuery(className: "Groups")
        query.orderByDescending("EndTime")
        query.whereKey("EndTime", greaterThan: NSDate())
        query.findObjectsInBackgroundWithTarget(self, selector: "loadedGroups:")
    }
    
    func loadedGroups(Objects: [PFObject]) {
        var temp = NSMutableArray()
        for object: PFObject in Objects as [PFObject] {
            temp.addObject(object)
        }
        groupsData = temp
        groupsTable.reloadData()
    }
    
    func cleanJoins() {
        var query = PFQuery(className: "Join")
        query.whereKey("UserID", equalTo: theUserMgr.id)
        query.findObjectsInBackgroundWithTarget(self, selector: "loadedJoins:")
    }
    
    func loadedJoins(Objects: [PFObject]) {
        for object: PFObject in Objects {
            object.delete()
        }
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return groupsData.count
    }
    
    // Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
    // Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 80
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var cell: UITableViewCell? = tableView.dequeueReusableCellWithIdentifier("GroupsCell", forIndexPath: indexPath) as? UITableViewCell
        if (cell == nil) {
            cell = UITableViewCell(style: UITableViewCellStyle.Subtitle, reuseIdentifier: "GroupsCell")
        }
        
        cell!.textLabel.text = groupsData.objectAtIndex(indexPath.row).objectForKey("Title") as? String
        var subtitle = groupsData.objectAtIndex(indexPath.row).objectForKey("Place") as? String
        var theDate = groupsData.objectAtIndex(indexPath.row).objectForKey("EndTime") as NSDate
        var formatter = NSDateFormatter()
        formatter.setLocalizedDateFormatFromTemplate("hh:mm")
        var timeString: String = formatter.stringFromDate(theDate)
        subtitle! = subtitle! + " till " + timeString
        subtitle! = subtitle! + " by " + (groupsData.objectAtIndex(indexPath.row).objectForKey("Creator") as String)
        cell!.detailTextLabel?.text = subtitle!
        return cell!
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        var join = PFObject(className: "Join")
        join.setObject(groupsData.objectAtIndex(indexPath.row).objectId, forKey: "GroupID")
        join.setObject(theUserMgr.name, forKey: "UserName")
        join.setObject(theUserMgr.id, forKey: "UserID")
        join.saveInBackgroundWithTarget(self, selector: "saved:error:")
        theUserMgr.groupId = groupsData.objectAtIndex(indexPath.row).objectId
        theUserMgr.groupName = groupsData.objectAtIndex(indexPath.row).objectForKey("Title") as String
        tableView.deselectRowAtIndexPath(indexPath, animated: false)
    }
    
    func saved(result: NSNumber, error: NSError?) {
        if (error == nil) {
            let storyboard = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle())
            var vc = storyboard.instantiateViewControllerWithIdentifier("GroupChat") as UIViewController
            self.showViewController(vc, sender: self)
        } else {
            var alert = UIAlertController(title: "Failure", message: "You failed to join the group.", preferredStyle: UIAlertControllerStyle.Alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: nil))
            self.presentViewController(alert, animated: true, completion: nil)
        }
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1;
    }
    
}

