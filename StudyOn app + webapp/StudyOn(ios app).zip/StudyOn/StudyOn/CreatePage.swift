//
//  CreatePage.swift
//  StudyOn
//
//  Created by justin cheng on 25/10/14.
//  Copyright (c) 2014 One Mistakes. All rights reserved.
//
//
//  GroupsPage.swift
//  StudyOn
//
//  Created by justin cheng on 25/10/14.
//  Copyright (c) 2014 One Mistakes. All rights reserved.
//

import UIKit

class CreatePage: UIViewController, UITextFieldDelegate {
    
    @IBOutlet var titleField: UITextField!
    @IBOutlet var placeField: UITextField!
    @IBOutlet var datePicker: UIDatePicker!
    
    var groupsData = NSMutableArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    @IBAction func createGroup() {
        if (titleField.text.isEmpty) {
            var alert = UIAlertController(title: "Wait a sec", message: "Please type in the title.", preferredStyle: UIAlertControllerStyle.Alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: nil))
            self.presentViewController(alert, animated: true, completion: nil)
            return
        }
        if (placeField.text.isEmpty) {
            var alert = UIAlertController(title: "Wait a sec", message: "Please type in the place.", preferredStyle: UIAlertControllerStyle.Alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: nil))
            self.presentViewController(alert, animated: true, completion: nil)
            return
        }
        
        
        var group = PFObject(className: "Groups")
        group.setObject(titleField.text, forKey: "Title")
        group.setObject(placeField.text, forKey: "Place")
        group.setObject(datePicker.date, forKey: "EndTime")
        group.setObject(theUserMgr.name, forKey: "Creator")
        group.saveInBackgroundWithTarget(self, selector: "saved:error:")
    }
    
    func saved(result: NSNumber, error: NSError?) {
        if (error == nil) {
            var alert = UIAlertController(title: "Success", message: "\(titleField.text as String) is created.", preferredStyle: UIAlertControllerStyle.Alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: nil))
            self.presentViewController(alert, animated: true, completion: nil)
        } else {
            var alert = UIAlertController(title: "Failure", message: "\(titleField.text as String) is not created.", preferredStyle: UIAlertControllerStyle.Alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: nil))
            self.presentViewController(alert, animated: true, completion: nil)
        }
    }
    
}

