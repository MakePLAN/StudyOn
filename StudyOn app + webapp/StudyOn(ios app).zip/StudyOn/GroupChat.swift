//
//  GroupChat.swift
//  StudyOn
//
//  Created by justin cheng on 25/10/14.
//  Copyright (c) 2014 One Mistakes. All rights reserved.
//

import UIKit

class GroupChat: UIViewController, UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate {

    let MAX_ENTRIES_LOADED = 500
    var originalH: CGFloat = 0
    
    @IBOutlet var nav: UINavigationItem!
    @IBOutlet var tfEntry: UITextField!
    @IBOutlet var chatTable: UITableView!
    
    var keyboardState = 0
    
    var chats = NSMutableArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        nav.title = theUserMgr.groupName
        originalH = self.view.frame.size.height;
        findJoinId()
        loadChats()
    }
    
    override func viewWillAppear(animated: Bool) {
        registerForKeyboardNotifications()
    }
    
    override func viewWillDisappear(animated: Bool) {
        freeKeyboardNotifications()
    }
    
    func findJoinId() {
        var query = PFQuery(className: "Join")
        query.whereKey("UserID", equalTo: theUserMgr.id)
        query.findObjectsInBackgroundWithTarget(self, selector: "foundID:")
    }
    
    func foundID(Objects: [PFObject]) {
        theUserMgr.joinObject = Objects.first?
        if (theUserMgr.joinObject == nil) {
            self.removeFromParentViewController()
        }
    }
    
    func loadChats() {
        var query = PFQuery(className: "Chat")
        query.whereKey("GroupID", equalTo: theUserMgr.groupId)
        query.orderByAscending("createdAt")
        query.findObjectsInBackgroundWithTarget(self, selector: "loadedChats:")
    }
    
    func loadedChats(Objects: [PFObject]) {
        var temp = NSMutableArray()
        for object: PFObject in Objects {
            temp.addObject(object)
        }
        chats = temp
        chatTable.reloadData()
    }
    
    override func willMoveToParentViewController(parent: UIViewController?) {
        if (theUserMgr.joinObject != nil) {
            theUserMgr.joinObject!.deleteEventually()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return chats.count
    }
    
    // Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
    // Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 60
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var cell: ChatCell? = tableView.dequeueReusableCellWithIdentifier("ChatCell", forIndexPath: indexPath) as? ChatCell
        if (cell == nil) {
            cell = ChatCell(style: UITableViewCellStyle.Default, reuseIdentifier: "ChatCell")
        }
        cell!.userLabel.text = chats.objectAtIndex(indexPath.row).objectForKey("Name") as? String
        var theDate: NSDate = chats.objectAtIndex(indexPath.row).createdAt as NSDate
        var formatter = NSDateFormatter()
        formatter.setLocalizedDateFormatFromTemplate("hh:mm")
        cell!.timeLabel.text = formatter.stringFromDate(theDate)
        
        sizeLabel(cell!.userLabel, labelRect: cell!.userLabel.frame)
        sizeLabel(cell!.timeLabel, labelRect: cell!.timeLabel.frame)
        
        cell!.msgTextView.text = chats.objectAtIndex(indexPath.row).objectForKey("Message") as? String
        
        return cell!
    }

    func sizeLabel(label: UILabel, labelRect: CGRect) {
        label.frame = labelRect
        var fontSize: CGFloat = 300
        var minFontSize: CGFloat = 5
        while (fontSize > minFontSize) {
            label.font = UIFont(name: label.font.fontName, size:fontSize)
            label.sizeToFit()
            if (label.frame.size.width < labelRect.size.width) {
                return
            }
            fontSize--
        }
    }
    
    func registerForKeyboardNotifications() {
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWasShown:", name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillHide:", name: UIKeyboardWillHideNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillChangeFrame:", name: UIKeyboardDidChangeFrameNotification, object: nil)
    }
    
    func freeKeyboardNotifications() {
        NSNotificationCenter.defaultCenter().removeObserver(self, name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().removeObserver(self, name: UIKeyboardWillHideNotification, object: nil)
        NSNotificationCenter.defaultCenter().removeObserver(self, name: UIKeyboardDidChangeFrameNotification, object: nil)
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        if (textField.text.isEmpty) {
            return true
        }
        
        var newMessage = PFObject(className: "Chat")
        newMessage.setObject(textField.text, forKey: "Message")
        newMessage.setObject(theUserMgr.name, forKey: "Name")
        newMessage.setObject(theUserMgr.groupId, forKey: "GroupID")
        newMessage.saveInBackgroundWithTarget(self, selector: "posted:error:")
        
        textField.text = ""
        return true
    }
    
    func posted(result: NSNumber, error: NSError?) {
        loadChats()
    }
    
    func keyboardWasShown(aNotification: NSNotification) {
        if (keyboardState == 0) {
            var info: NSDictionary = aNotification.userInfo! as NSDictionary
            var keyboardFrame = CGRect()
            info.objectForKey(UIKeyboardFrameBeginUserInfoKey)?.getValue(&keyboardFrame)
            self.view.frame = CGRectMake(self.view.frame.origin.x, self.view.frame.origin.y,
                self.view.frame.size.width, originalH-keyboardFrame.size.height)
            keyboardState = 1
        }
    }
    
    func keyboardWillChangeFrame(aNotification: NSNotification) {
        if (keyboardState == 1) {
            var info: NSDictionary = aNotification.userInfo! as NSDictionary
            var keyboardFrame = CGRect()
            info.objectForKey(UIKeyboardFrameEndUserInfoKey)?.getValue(&keyboardFrame)
            self.view.frame = CGRectMake(self.view.frame.origin.x, self.view.frame.origin.y,
                self.view.frame.size.width, originalH - keyboardFrame.size.height)
        }
    }
    
    func keyboardWillHide(aNotification: NSNotification) {
        var info: NSDictionary = aNotification.userInfo! as NSDictionary
        var keyboardFrame = CGRect()
        info.objectForKey(UIKeyboardFrameEndUserInfoKey)?.getValue(&keyboardFrame)
        self.view.frame = CGRectMake(self.view.frame.origin.x, self.view.frame.origin.y,
            self.view.frame.size.width, originalH)
        keyboardState = 0
    }
    
}